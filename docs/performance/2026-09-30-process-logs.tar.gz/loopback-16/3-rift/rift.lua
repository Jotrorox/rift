return {
    listeners = { public = "127.0.0.1:37857" },
    backends = { backend = "127.0.0.1:44763" },
    routes = { public = "backend" },
    limits = { max_connections = 16384 },
}
