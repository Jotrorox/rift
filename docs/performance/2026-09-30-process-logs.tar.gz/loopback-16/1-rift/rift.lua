return {
    listeners = { public = "127.0.0.1:46297" },
    backends = { backend = "127.0.0.1:38173" },
    routes = { public = "backend" },
    limits = { max_connections = 16384 },
}
