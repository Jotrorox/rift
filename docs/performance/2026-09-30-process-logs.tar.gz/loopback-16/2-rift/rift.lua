return {
    listeners = { public = "127.0.0.1:56453" },
    backends = { backend = "127.0.0.1:35125" },
    routes = { public = "backend" },
    limits = { max_connections = 16384 },
}
