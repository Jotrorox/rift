return {
    listeners = { public = "127.0.0.1:34927" },
    backends = { backend = "127.0.0.1:36337" },
    routes = { public = "backend" },
    limits = { max_connections = 16384 },
}
