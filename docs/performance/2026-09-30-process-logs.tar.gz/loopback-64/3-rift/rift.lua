return {
    listeners = { public = "127.0.0.1:42577" },
    backends = { backend = "127.0.0.1:51997" },
    routes = { public = "backend" },
    limits = { max_connections = 16384 },
}
